#ifndef _DEBUG_UTIL_H
#define _DEBUG_UTIL_H
#include "header.h"
using namespace std;
void debugUtil(string functionName, string message);

void debugUtil(string message);

#endif
